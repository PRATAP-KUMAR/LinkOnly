'use strict';

const { GObject, St, Gio, GLib } = imports.gi;

const Lang = imports.lang;
const Main = imports.ui.main;
const PanelMenu = imports.ui.panelMenu;
const PopupMenu = imports.ui.popupMenu;
const Util = imports.misc.util;
const ExtensionUtils = imports.misc.extensionUtils;
const Me = ExtensionUtils.getCurrentExtension();

const Menu = Main.panel.statusArea.a11y.menu
const accessIndicator = imports.ui.status.accessibility.ATIndicator

let customButton;
let boolean;
let extSettings = ExtensionUtils.getSettings('org.gnome.shell.extensions.custom-button');



var customAccessIndicator = new Lang.Class({
    Name: "custom Access Indicator",
    Extends: PanelMenu.SystemIndicator,

_init: function() {

       	this._createMenu();
	this._gsettingsChanged();
	this._takeAction();
},

//    
_createMenu: function() {
	customButton = accessIndicator.prototype._buildItem('Custom Accessibility Button', 'org.gnome.shell.extensions.custom-button', 'myscript');
    	Menu.addMenuItem(customButton);
},

//
_gsettingsChanged: function() {
extSettings.connect("changed::myscript", this._takeAction.bind(this));
},

//
_takeAction: function() {

boolean = extSettings.get_boolean('myscript');

if (boolean) {
Util.spawnCommandLine('bash /opt/myTool/activate.sh');
} else {
Util.spawnCommandLine('bash /opt/myTool/deactivate.sh');
};
},

//
destroy: function() {
Menu.box.remove_actor(customButton);
}
});	

//
function init() {}
//
let modifiedMenu;
//
function enable() {
modifiedMenu = new customAccessIndicator();
}
//
function disable() {
modifiedMenu.destroy();
}
