'use strict'

let native = imports.ui.appDisplay.AppIcon.prototype._updateRunningStyle;

class removeDotExtension {
    constructor() {
    }
    
    _modified() {
            this._dot.hide();
    }
    
    enable() {
    imports.ui.appDisplay.AppIcon.prototype._updateRunningStyle = this._modified;
    }

    disable() {
    imports.ui.appDisplay.AppIcon.prototype._updateRunningStyle = native;
    }
}

function init() {
    return new removeDotExtension();
}
